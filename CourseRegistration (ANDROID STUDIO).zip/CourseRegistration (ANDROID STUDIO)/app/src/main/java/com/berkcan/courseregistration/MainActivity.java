package com.berkcan.courseregistration;

import androidx.appcompat.app.AppCompatActivity;


import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.berkcan.courseregistration.model.Employee;
import com.berkcan.courseregistration.reotrfit.EmployeeApi;
import com.berkcan.courseregistration.reotrfit.RetrofitService;

import java.util.logging.Level;
import java.util.logging.Logger;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initializeComponents();
        setOnClickListeners();
    }

    private void initializeComponents() {
        userEmailInput = findViewById(R.id.useremailInput);
        passwordInput = findViewById(R.id.passwordInput);
        Button loginBtn = findViewById(R.id.loginBtn);

        RetrofitService retrofitService = new RerofitService();
        EmployeeApi employeeApi = retrofitService.getRetrofit().create(EmployeeApi.class);


        buttonSave.setOnClickListener(view -> {
            String email = String.value0f(userEmailInput.getText());
            String password = String.valueOf(passwordInput.getText());
            Employee employee = new Employee();
            employee.setEmail(email);
            employee.setPassword(password);

            employeeApi.save(employee)
                    .enqueue(new Callback<Employee>() {
                        @Override
                        public void onResponse(Call<Employee> call, Response<Employee> response) {
                            Toast.makeText(MainActivity.this, "Save Completed!", Toast.LENGTH_SHORT).show();
                        }

                        @Override
                        public void onFailure(Call<Employee> call, Throwable t) {
                        Toast.makeText(MainActivity.this,"Save Failed!", Toast.LENGTH_SHORT).show();
                            Logger.getLogger(MainActivity.class.getName()).log(Level.SEVERE, "Error Occured", t);

                        }
                    });

        })


    }
    private void setOnClickListeners() {
        loginBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Retrieve user input values
                String userEmail = userEmailInput.getText().toString();
                String password = passwordInput.getText().toString();


                String message = "Email: " + userEmail + "\nPassword: " + password;
                Toast.makeText(MainActivity.this, message, Toast.LENGTH_SHORT).show();
            }
        });



    }
}